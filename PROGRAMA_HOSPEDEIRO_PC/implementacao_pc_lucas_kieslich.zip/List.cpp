
#include "List.h"

List::List() {
   head = 0;
}

List::~List() {
  Node* cursor = head;
  while(head) {
    cursor = cursor->getNext();
    delete head;
    head = cursor;
  }
  head = 0; // Officially empty
}

void List::insertBeforeFirst(int ldr1, int ldr2, int ldr_dig, int step_mot, int hr, int min, int sec, int ampm) {
  head = new Node(ldr1, ldr2, ldr_dig, step_mot, hr, min, sec, ampm, head);
}

void List::insertAfterLast(int ldr1, int ldr2, int ldr_dig, int step_mot, int hr, int min, int sec, int ampm) {
  Node* p = head;
  Node* q = head;

  if (head == 0)
     head = new Node(ldr1, ldr2, ldr_dig, step_mot, hr, min, sec, ampm, head);
  else {
     while (q != 0) {
        p = q;
        q = p->getNext();
     }
     p->setNext(new Node(ldr1, ldr2, ldr_dig, step_mot, hr, min, sec, ampm, 0));
  }
}

int List::readFirst(int &retldr1, int &retldr2, int &retldr_dig, int &retstep_mot, int &rethr, int &retmin, int &retsec, int &retampm) {
   if (head != 0){
  //   cout << "Removendo: " << head << endl;
  //   cout << "e fica:" << head->getVal() << endl;
     retldr1 = head->getldr1();
 
     retldr2 = head->getldr2();
   
     retldr_dig = head->getldr_dig();

     retstep_mot = head->getstep_mot();

     rethr = head->gethr();

     retmin = head->getmin();

    retsec = head->getsec();

    retampm = head->getampm();
 
   }
}

int List::removeFirst(int &retldr1, int &retldr2, int &retldr_dig, int &retstep_mot, int &rethr, int &retmin, int &retsec, int &retampm) {

  if (head != 0){
  //   cout << "Removendo: " << head << endl;
  //   cout << "e fica:" << head->getVal() << endl;
     retldr1 = head->getldr1();
     retldr2 = head->getldr2();
     retldr_dig = head->getldr_dig();
     retstep_mot = head->getstep_mot();
     rethr = head->gethr();
     retmin = head->getmin();
     retsec = head->getsec();
     retampm = head->getampm();
     Node* oldHead = head;
     head = head->getNext();
     delete oldHead;
  }
 
}

int List::listAll() {
  Node* aux = head;
  int Node_number = 0;
  while (aux != 0){
  Node_number++;
    cout << aux->getldr1() << endl;
    cout << aux->getldr2() << endl;
    cout << aux->getldr_dig() << endl;
    cout << aux->getstep_mot() << endl;
    cout << aux->gethr() << endl;
    cout << aux->getmin() << endl;
    cout << aux->getsec() << endl;
    cout << aux->getampm() << endl;
    aux = aux->getNext();
  }
  return Node_number;
}
