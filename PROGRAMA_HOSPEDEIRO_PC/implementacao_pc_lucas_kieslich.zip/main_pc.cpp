  #include <iostream>
  
  #include "List.h"
  
  
  using namespace std;
  
  int main(){
  
  List receiveList;

  unsigned char menu = '0';

  while(menu != '4')
  {

    cout << "1 - SOLICITAR DADOS PELA UART." << endl;
    cout << "2 - LISTAR LOG (FILA)." << endl;
    cout << "3 - STATUS DO SISTEMA" << endl;
    cout << "4 - SISTEMA DESATIVADO" << endl;
    cin >> menu;

    switch(menu)
    {
      case '1': 
      {
        char commdaux = 'l';
        int dadosR[8] = {0};// buffer temporário para recebimento dos dados enviados pela uart.
        
 //       uart1.OpenSerial();
  //      uart1.SetSerialParameter();
    //    uart1.SerialWrite(commdaux);

        if (commdaux == 'l')                                              
        { /*Tratamento da construção da fila com os dados recebidos*/
          
  //        uart1.SerialRead(dadosR);
          int SerialData[8] = {255, 0, 0, 2, 11, 55, 23, 1}; // exemplo de dados lidos pela UART
          for (int i = 0; i < 8; i++)
          {
            dadosR[i] = SerialData[i];
          }
          
          cout << " O dado recebido foi: " << dadosR[0] << ", " << dadosR[1] << ", " << dadosR[2] << ", " << dadosR[3] << ", " << dadosR[4] << ":" << dadosR[5] << ":" << dadosR[6] << " ";
            if (dadosR[7] == 1){
              cout << "am" << endl;
            }
            else{
              cout << "pm" << endl;  
            }
          receiveList.insertAfterLast(dadosR[0], dadosR[1], dadosR[2], dadosR[3], dadosR[4], dadosR[5], dadosR[6], dadosR[7]);
          for (int i = 0; i < 8; i++)
          {
            dadosR[i] = 0;
          }
        }
       
                
   //     uart1.CloseSerial();
        break;
      }
      case '2':
      receiveList.listAll();

      break;
        //cout << "Os eventos ocorridos nesse periodo foram: " << endl;
        //log1.listAll();

      case '3': // status do sistema
      { 
        int auxldr1, auxldr2, auxldr_dig, auxstep_mot, aux_hr, aux_min, aux_sec, aux_ampm;
        receiveList.readFirst(auxldr1, auxldr2, auxldr_dig, auxstep_mot, aux_hr, aux_min, aux_sec, aux_ampm);
        if (auxldr_dig == 1){
          cout << "Sistema estabilizado! Requisitos mínimos de iluminação atendidos!" << endl;
        }
        else{
          cout << "Nível de iluminação abaixo do ideal. Buscando posição ideal..." << endl;
            if(auxldr1 > auxldr2){
              cout << "Movendo sistema para a direita" << endl;
            }
            else if(auxldr1 < auxldr2){
              cout << "Movendo sistema para a esquerda" << endl;
            }
        }
        break;
      }
      case '4':
      { 
        cout << "Sistema desativado." << endl;
        break;
      }

      default:
      {
        cout << "1 - SOLICITAR DADOS PELA UART." << endl;
        cout << "2 - LISTAR LOG (FILA)." << endl;
        cout << "3 - STATUS DO SISTEMA" << endl;
        cout << "4 - SISTEMA DESATIVADO" << endl;
        cin >> menu;
      }
    }
    
  }

return 0 ;
  
}